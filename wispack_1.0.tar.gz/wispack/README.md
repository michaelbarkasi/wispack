# wispack
 Rcpp implementation of warped-sigmoid Poisson-process mixed-effect models

# idea of pinned-age test: to test whether model is underconstrained, pin ages to the values found for them 
  in the full fit while bootstrapping. Presumably the optimal fits on the resamples will have
  different values. If the model is underconstrained and can make up for these sub-optimal values 
  by adjusting other parameters (presumably the random effects), then the bootstrapped fits will be
  just as good, whether or not the ages are pinned. 