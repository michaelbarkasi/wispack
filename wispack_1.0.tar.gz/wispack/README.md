# wispack
 Rcpp implementation of warped-sigmoid Poisson-process mixed-effect models
