

# Load demo data
#data_path <- system.file("extdata", "countdata.csv", package = "wispack")
#countdata <- read.csv(data_path)

